import cv2
import os
import playsound
from gtts import gTTS
import smtplib
from email.mime.text import MIMEText

# -------------------------
# 1. Voice / Siren Alerts
# -------------------------
def speak(text):
    try:
        tts = gTTS(text=text, lang='en')
        filename = "alert.mp3"
        tts.save(filename)
        playsound.playsound(filename)
        os.remove(filename)
    except Exception as e:
        print("⚠️ TTS failed:", e)

def play_siren():
    try:
        siren_file = "siren.mp3" # Keep siren.mp3 in same folder
        playsound.playsound(siren_file)
    except Exception as e:
        print("⚠️ Siren sound failed:", e)

# -------------------------
# 2. SOS via Email
# -------------------------
def send_sos():
    sender = "aryaraut211@gmail.com"
    password = "tpjv hwle sszz gdun"   # Gmail App Password
    receiver = "aryaraut211@gmail.com"

    msg = MIMEText("🚨 EMERGENCY: Fire/Smoke detected by RoomRover! Immediate response required.")
    msg["Subject"] = "🔥 SOS ALERT from RoomRover"
    msg["From"] = sender
    msg["To"] = receiver

    try:
        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server.login(sender, password)
        server.sendmail(sender, receiver, msg.as_string())
        server.quit()
        print("✅ SOS email sent to authorities!")
        speak("Emergency! SOS has been sent to authorities.")
    except Exception as e:
        print("❌ Failed to send SOS:", e)
        speak("Emergency detected but SOS could not be sent.")

# -------------------------
# 3. Fire/Smoke Detection
# -------------------------
def detect_fire_smoke():
    cap = cv2.VideoCapture(0)  # Open laptop camera
    fire_detected = False
    fire_count = 0  # consecutive fire frames

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Convert to HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Fire color range
        lower_fire = (0, 50, 50)
        upper_fire = (50, 255, 255)
        mask = cv2.inRange(hsv, lower_fire, upper_fire)

        # Reduce noise
        mask = cv2.GaussianBlur(mask, (15, 15), 0)

        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        fire_area = 0
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 1000:   # ignore very small red objects
                fire_area += area

        print("🔥 Fire-like area:", fire_area)

        # Fire detection condition
        if fire_area > 150000:  # Adjust threshold after testing
            fire_count += 1
        else:
            fire_count = 0

        # Trigger after consecutive frames
        if fire_count >= 5 and not fire_detected:
            fire_detected = True
            print("🚨 FIRE/SMOKE DETECTED! Emergency Protocol Activated.")
            
            # Siren + Voice
            speak("Warning! Fire or smoke detected.")
            play_siren()

            # Send SOS (Email)
            send_sos()

            break

    cap.release()

# -------------------------
# Main Program
# -------------------------
if __name__ == "__main__":
    print("🔍 RoomRover monitoring camera for fire/smoke...")
    detect_fire_smoke()
