import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import threading

from utils.qa_engine import QAEngine
from utils.voice import speak_text

class GradientFrame(tk.Canvas):
	"""A frame with a vertical gradient background."""
	def __init__(self, parent, color1, color2, *args, **kwargs):
		tk.Canvas.__init__(self, parent, *args, **kwargs)
		self._color1 = color1
		self._color2 = color2
		self.bind("<Configure>", self._draw_gradient)

	def _draw_gradient(self, event=None):
		self.delete("gradient")
		width = self.winfo_width()
		height = self.winfo_height()
		limit = height
		(r1, g1, b1) = self.winfo_rgb(self._color1)
		(r2, g2, b2) = self.winfo_rgb(self._color2)
		r_ratio = float(r2 - r1) / limit
		g_ratio = float(g2 - g1) / limit
		b_ratio = float(b2 - b1) / limit

		for i in range(limit):
			nr = int(r1 + (r_ratio * i))
			ng = int(g1 + (g_ratio * i))
			nb = int(b1 + (b_ratio * i))
			color = f"#{nr:04x}{ng:04x}{nb:04x}"
			self.create_line(0, i, width, i, tags=("gradient",), fill=color)
		self.lower("gradient")


class TextVoiceApp:
	def __init__(self, root: tk.Tk):
		self.root = root
		self.root.title("College Q&A - Text to Voice")
		self.root.geometry("800x600")
		self.root.minsize(700, 480)

		self.engine = QAEngine()
		self.typing_job = None

		# --- Theme and Styles ---
		self.BG_COLOR = "#1F1F1F"
		self.TEXT_COLOR = "#EAEAEA"
		self.WIDGET_BG = "#2B2B2B"
		self.TITLE_COLOR = "#FFFFFF"
		self.ACCENT_PRIMARY = "#007ACC"
		self.ACCENT_SECONDARY = "#5A5A5A"
		self.ACCENT_TERTIARY = "#4CAF50" # For Speak button
		self.BORDER_COLOR = "#555555"

		style = ttk.Style()
		try:
			style.theme_use("clam")
		except Exception:
			pass

		# General widget styling
		style.configure(".", background=self.BG_COLOR, foreground=self.TEXT_COLOR, font=("Segoe UI", 10))
		style.configure("TFrame", background="transparent") # Make frames transparent for gradient
		style.configure("TLabel", padding=5, font=("Segoe UI", 11))
		# Primary Button Style ('Ask')
		style.configure("Primary.TButton", padding=8, font=("Segoe UI", 10, "bold"), foreground="white", background=self.ACCENT_PRIMARY, borderwidth=0)
		style.map("Primary.TButton", background=[("active", "#005f9e")])
		# Secondary Button Style ('Clear')
		style.configure("Secondary.TButton", padding=8, font=("Segoe UI", 10), foreground=self.TEXT_COLOR, background=self.ACCENT_SECONDARY, borderwidth=0)
		style.map("Secondary.TButton", background=[("active", "#404040")])
		# Voice Button Style ('Speak')
		style.configure("Voice.TButton", padding=8, font=("Segoe UI", 10, "bold"), foreground="white", background=self.ACCENT_TERTIARY, borderwidth=0)
		style.map("Voice.TButton", background=[("active", "#45a049")])

		style.configure("TEntry", fieldbackground=self.WIDGET_BG, foreground=self.TEXT_COLOR, insertcolor=self.TEXT_COLOR)
		style.configure("TSeparator", background=self.BORDER_COLOR)

		self._build_ui()

	def _build_ui(self) -> None:
		gradient_bg = GradientFrame(self.root, color1="#2E2E2E", color2="#1E1E1E")
		gradient_bg.pack(fill="both", expand=True)

		container = ttk.Frame(gradient_bg, padding=20)
		container.pack(fill=tk.BOTH, expand=True)
		container.configure(style="TFrame")

		title = ttk.Label(container, text="College Q&A Assistant", font=("Segoe UI", 22, "bold"),
						  foreground=self.TITLE_COLOR)
		title.pack(anchor=tk.W, pady=(0, 8))

		self.prompt_label = ttk.Label(container, text="Enter your question below:")
		self.prompt_label.pack(anchor=tk.W)

		self.entry = tk.Text(container, height=4, wrap=tk.WORD, font=("Segoe UI", 11),
							 background=self.WIDGET_BG, foreground=self.TEXT_COLOR,
							 insertbackground=self.TEXT_COLOR, relief=tk.SOLID,
							 borderwidth=1, highlightthickness=1, highlightbackground=self.BORDER_COLOR, highlightcolor=self.ACCENT_PRIMARY)
		self.entry.pack(fill=tk.X, pady=6)

		btn_row = ttk.Frame(container)
		btn_row.pack(fill=tk.X, pady=4)

		self.ask_btn = ttk.Button(btn_row, text="Ask", command=self.on_ask, style="Primary.TButton")
		self.ask_btn.pack(side=tk.LEFT, ipadx=10)

		self.clear_btn = ttk.Button(btn_row, text="Clear", command=self.on_clear, style="Secondary.TButton")
		self.clear_btn.pack(side=tk.LEFT, padx=(8, 0))

		self.speak_btn = ttk.Button(btn_row, text="🎤 Speak", command=self.on_speak, style="Voice.TButton")
		self.speak_btn.pack(side=tk.LEFT, padx=(8, 0))

		sep = ttk.Separator(container)
		sep.pack(fill=tk.X, pady=15)

		ans_label = ttk.Label(container, text="Answer:", font=("Segoe UI", 11, "bold"))
		ans_label.pack(anchor=tk.W)

		self.answer = tk.Text(container, height=12, wrap=tk.WORD, state=tk.DISABLED, font=("Segoe UI", 11),
							   background=self.WIDGET_BG, foreground=self.TEXT_COLOR,
							   relief=tk.FLAT, borderwidth=2, highlightthickness=1,
							   highlightbackground=self.BORDER_COLOR)
		self.answer.pack(fill=tk.BOTH, expand=True)
		foot = ttk.Label(container, text="Tip: Press Enter to submit (Shift+Enter for newline)", foreground="#888")
		foot.pack(anchor=tk.W, pady=(6, 0))

		self.entry.bind("<Return>", self._enter_submit)
		self.entry.bind("<Shift-Return>", lambda e: None)

	def _enter_submit(self, event):
		if event.state & 0x0001:  # Shift pressed
			return
		self.on_ask()
		return "break"

	def on_speak(self) -> None:
		"""Handles the 'Speak' button click by starting voice recognition in a new thread."""
		self.speak_btn.config(state=tk.DISABLED)
		self.ask_btn.config(state=tk.DISABLED)
		threading.Thread(target=self._recognize_speech, daemon=True).start()

	def _recognize_speech(self) -> None:
		"""Listens for audio and converts it to text."""
		try:
			import speech_recognition as sr
		except ImportError:
			self.root.after(0, lambda: messagebox.showerror("Error", "SpeechRecognition library not found. Please install it."))
			self.root.after(0, self._reset_buttons)
			return

		recognizer = sr.Recognizer()
		with sr.Microphone() as source:
			self.root.after(0, lambda: self.prompt_label.config(text="Listening... Please speak your question."))
			recognizer.adjust_for_ambient_noise(source, duration=0.5)
			try:
				audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
				self.root.after(0, lambda: self.prompt_label.config(text="Recognizing..."))
				text = recognizer.recognize_google(audio)
				
				# Update UI with recognized text and ask
				self.root.after(0, lambda: self.entry.delete("1.0", tk.END))
				self.root.after(0, lambda: self.entry.insert("1.0", text))
				self.root.after(0, self.on_ask)
			except sr.UnknownValueError:
				self.root.after(0, lambda: messagebox.showwarning("Voice Recognition", "Could not understand audio or no speech detected."))
			except sr.WaitTimeoutError:
				self.root.after(0, lambda: messagebox.showwarning("Voice Recognition", "No speech detected within the timeout period."))
			except sr.RequestError as e:
				self.root.after(0, lambda: messagebox.showerror("Voice Recognition", f"Could not request results from Google Speech Recognition service; {e}"))
			except Exception as e:
				self.root.after(0, lambda: messagebox.showerror("Voice Recognition", f"An unexpected error occurred: {e}"))
		self.root.after(0, self._reset_ui_state)

	def on_clear(self) -> None:
		self.entry.delete("1.0", tk.END)
		self._set_answer_text("")

	def _set_answer_text(self, text: str) -> None:
		"""Directly sets the text of the answer box."""
		self.answer.config(state=tk.NORMAL)
		self.answer.delete("1.0", tk.END)
		self.answer.insert(tk.END, text)
		self.answer.config(state=tk.DISABLED)

	def _type_answer_effect(self, text: str, index: int = 0) -> None:
		"""Creates a typewriter effect for the answer."""
		if index < len(text):
			self.answer.insert(tk.END, text[index])
			self.answer.see(tk.END)  # Auto-scroll
			# Schedule the next character
			self.typing_job = self.root.after(25, lambda: self._type_answer_effect(text, index + 1))
		else:
			self.answer.config(state=tk.DISABLED)
			self._reset_buttons() # Re-enable buttons
			self.typing_job = None

	def _reset_buttons(self):
		"""Resets buttons to their normal state."""
		self.ask_btn.config(state=tk.NORMAL)
		self.speak_btn.config(state=tk.NORMAL)

	def _reset_ui_state(self):
		self.prompt_label.config(text="Enter your question below:")
		self._reset_buttons()
	def on_ask(self) -> None:
		q = self.entry.get("1.0", tk.END).strip()
		if not q:
			messagebox.showinfo("Empty question", "Please enter a non-empty question.")
			return
		ans = self.engine.ask(q)

		# Stop any previous typing job
		if self.typing_job:
			self.root.after_cancel(self.typing_job)

		# Clear the answer box and prepare for typing
		self.answer.config(state=tk.NORMAL)
		self.answer.delete("1.0", tk.END)
		self.ask_btn.config(state=tk.DISABLED)
		self.speak_btn.config(state=tk.DISABLED)

		# Start the typewriter effect
		self._type_answer_effect(ans)

		speak_text(ans)


def main() -> None:
	root = tk.Tk()
	TextVoiceApp(root)
	root.mainloop()


if __name__ == "__main__":
	main()
