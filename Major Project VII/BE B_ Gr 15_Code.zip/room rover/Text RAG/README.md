Text RAG - College Q&A (Text Input, Voice Output)

Overview
This app answers college-related questions from your local knowledge file. You can use a CLI or a simple GUI. Input is typed; answers are spoken using gTTS and also shown on screen.

Data
- Knowledge file: data/college_info.txt
- If missing or empty, the app starts and answers with a helpful message.

Configuration
- See config.py for defaults. Environment overrides:
  - DATA_PATH: path to the knowledge file (default: data/college_info.txt)
  - TOP_K: number of chunks to retrieve (default: 3)
  - CHUNK_SIZE: chunk size in characters (default: 600)
  - CHUNK_OVERLAP: overlap size (default: 60)
  - EMBEDDINGS_BACKEND: auto | none (default: auto) — auto tries sentence-transformers if installed.

Install (Windows-friendly)
1) Optional: create and activate a virtual environment
2) Install requirements:
   pip install -r requirements.txt

CLI Usage (text in, voice out)
Run:
  python main_text.py

You should see a prompt:
  Ask a question (or type 'exit'):

GUI Usage (impressive minimal UI)
Run:
  python ui_text_voice.py

- Enter your question in the text box and click "Ask" (or press Enter).
- The answer is displayed and spoken aloud via gTTS.

Notes
- The app falls back to simple keyword-based retrieval if sentence-transformers is not installed.
- No local HTTP API is used. The old API file has been removed per request.
- gTTS requires internet connectivity to generate speech.


