import os
import math
from typing import List, Tuple

import config


def _read_text_file(path: str) -> str:
	if not os.path.exists(path):
		return ""
	try:
		with open(path, "r", encoding="utf-8", errors="ignore") as f:
			return f.read()
	except Exception:
		return ""


def _parse_qa_pairs(text: str) -> List[Tuple[str, str]]:
	"""Parses text file with 'Q:' and 'A:' pairs, ignoring numbering."""
	text = text.replace("\r\n", "\n").replace("\r", "\n")
	lines = [line.strip() for line in text.split("\n") if line.strip()]
	if not lines:
		return []

	qa_pairs: List[Tuple[str, str]] = []
	current_q = None
	for line in lines:
		# Find 'Q:' marker, ignoring anything before it (like numbering)
		q_marker_pos = line.find("Q:")
		if q_marker_pos != -1:
			current_q = line[q_marker_pos + 2:].strip()
			continue

		# Find 'A:' marker, and associate it with the last question found
		a_marker_pos = line.find("A:")
		if a_marker_pos != -1 and current_q is not None:
			answer = line[a_marker_pos + 2:].strip()
			qa_pairs.append((current_q, answer))
			current_q = None  # Reset to find the next Q
	return qa_pairs


def _tokenize(s: str) -> List[str]:
	return [t for t in ''.join([c.lower() if c.isalnum() or c.isspace() else ' ' for c in s]).split() if t]


def _bow_vector(tokens: List[str]) -> dict:
	counts = {}
	for t in tokens:
		counts[t] = counts.get(t, 0) + 1
	return counts


def _cosine_sim(a: dict, b: dict) -> float:
	if not a or not b:
		return 0.0
	# dot product
	dot = 0.0
	for k, v in a.items():
		if k in b:
			dot += v * b[k]
	# magnitudes
	norm_a = math.sqrt(sum(v * v for v in a.values()))
	norm_b = math.sqrt(sum(v * v for v in b.values()))
	if norm_a == 0.0 or norm_b == 0.0:
		return 0.0
	return dot / (norm_a + 1e-9) / (norm_b + 1e-9)


class SimpleRAGEngine:
	"""A minimal RAG-style retriever + answerer.

	- Attempts to use sentence-transformers if available and allowed.
	- Falls back to keyword-based retrieval otherwise.
	"""

	def __init__(self, data_path: str | None = None):
		self.data_path = data_path or config.DATA_PATH
		self.qa_pairs: List[Tuple[str, str]] = []
		self.questions: List[str] = []
		self._use_embeddings = False
		self._embeddings = None
		self._embedder = None
		self._init_backend()
		self._load_corpus()

	def _init_backend(self) -> None:
		if config.EMBEDDINGS_BACKEND == "none":
			self._use_embeddings = False
			return
		try:
			from sentence_transformers import SentenceTransformer
			self._embedder = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
			self._use_embeddings = True
		except Exception:
			self._use_embeddings = False

	def _load_corpus(self) -> None:
		text = _read_text_file(self.data_path)
		if not text:
			self.qa_pairs = []
			self.questions = []
			self._embeddings = None
			return
		self.qa_pairs = _parse_qa_pairs(text)
		self.questions = [q for q, a in self.qa_pairs]
		if self._use_embeddings and self.questions:
			try:
				self._embeddings = self._embedder.encode(self.questions, convert_to_numpy=True, normalize_embeddings=True)
			except Exception:
				self._use_embeddings = False
				self._embeddings = None

	def reload(self) -> None:
		self._load_corpus()

	def _retrieve(self, question: str, top_k: int) -> List[Tuple[int, float]]:
		if not self.questions:
			return []
		q = question.strip()
		if not q:
			return []
		if self._use_embeddings and self._embeddings is not None:
			try:
				q_vec = self._embedder.encode([q], convert_to_numpy=True, normalize_embeddings=True)[0]
				# cosine similarity via dot product since normalized
				import numpy as np
				sims = (self._embeddings @ q_vec).tolist()
				idx_scores = sorted([(i, sims[i]) for i in range(len(self.questions))], key=lambda x: x[1], reverse=True)
				return idx_scores[:max(1, top_k)]
			except Exception:
				pass
		# Fallback: simple bag-of-words cosine
		q_vec = _bow_vector(_tokenize(q))
		scored: List[Tuple[int, float]] = []
		cache: List[dict] = []
		for i, c in enumerate(self.questions):
			c_vec = _bow_vector(_tokenize(c))
			cache.append(c_vec)
			scored.append((i, _cosine_sim(q_vec, c_vec)))
		scored.sort(key=lambda x: x[1], reverse=True)
		return scored[:max(1, top_k)]

	def ask(self, question: str) -> str:
		q = (question or "").strip()
		if not q:
			return "Please ask a question."
		if not self.qa_pairs:
			return (
				"Knowledge base is empty or missing. Make sure '" + self.data_path + "' exists."
			)
		results = self._retrieve(q, config.TOP_K)
		if not results:
			return "I could not find relevant information in the knowledge base."
		best_idx, _ = results[0]
		# Return the answer part of the best matching Q&A pair
		return self.qa_pairs[best_idx][1]
