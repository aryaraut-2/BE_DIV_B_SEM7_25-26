from utils.rag_engine import SimpleRAGEngine


class QAEngine:
	def __init__(self, rag: SimpleRAGEngine | None = None):
		self.rag = rag or SimpleRAGEngine()

	def ask(self, question: str) -> str:
		return self.rag.ask(question)


