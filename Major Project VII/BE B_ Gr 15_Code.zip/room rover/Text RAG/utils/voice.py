import os
import tempfile
from typing import Optional


def speak_text(text: str) -> Optional[str]:
	"""Generate speech from text using gTTS and play it. Returns path to the mp3 used, or None on failure.

	This function attempts to be robust on Windows using playsound to play MP3s.
	"""
	try:
		from gtts import gTTS
		from playsound import playsound
		tts = gTTS(text=text, lang="en")
		fd, path = tempfile.mkstemp(suffix=".mp3", prefix="tts_")
		os.close(fd)
		tts.save(path)
		playsound(path)
		return path
	except Exception:
		return None


