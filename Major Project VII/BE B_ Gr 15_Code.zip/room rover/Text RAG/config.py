import os


def get_env(name: str, default: str) -> str:
	value = os.getenv(name)
	return value if value is not None and value.strip() != "" else default


# Paths
DATA_PATH: str = get_env("DATA_PATH", os.path.join("data", "college_info.txt"))

# RAG settings
TOP_K: int = int(get_env("TOP_K", "3"))
CHUNK_SIZE: int = int(get_env("CHUNK_SIZE", "600"))
CHUNK_OVERLAP: int = int(get_env("CHUNK_OVERLAP", "60"))

# Embedding backend selection (optional). Supported values: "auto", "none"
# - auto: try to use sentence-transformers if installed, otherwise fallback to keyword match
# - none: always use keyword match
EMBEDDINGS_BACKEND: str = get_env("EMBEDDINGS_BACKEND", "auto").lower()


