from utils.qa_engine import QAEngine
from utils.voice import speak_text


def main() -> None:
	engine = QAEngine()
	print("Text RAG - College Q&A")
	print("Type your questions. Type 'exit' to quit.\n")
	while True:
		try:
			user_in = input("Ask a question (or type 'exit'): ").strip()
		except (EOFError, KeyboardInterrupt):
			print("\nGoodbye!")
			return
		if user_in.lower() in {"exit", "quit"}:
			print("Goodbye!")
			return
		if not user_in:
			print("Please enter a non-empty question.\n")
			continue
		answer = engine.ask(user_in)
		print(answer + "\n")
		# Voice output
		_ = speak_text(answer)


if __name__ == "__main__":
	main()


